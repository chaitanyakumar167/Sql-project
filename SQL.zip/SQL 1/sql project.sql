use ipl; 

-- checking Null values
-- ball by ball table
SELECT * FROM ball_by_ball where Match_Id is null OR Over_Id is null OR Ball_Id is null OR
	Innings_No is null OR Team_Batting is null OR Team_Bowling is null OR Striker_Batting_Position is null
	OR Striker is null OR Non_Striker is null OR Bowler is null;

-- batsman_scored table
SELECT * FROM batsman_scored where Match_Id is null OR Over_Id is null OR Ball_Id is null 
 OR Runs_Scored is null OR Innings_No is null;

-- batting_style table
SELECT * FROM batting_style where Batting_Id is null OR Batting_hand is null;

-- bowling_style table
SELECT * FROM bowling_style where Bowling_Id is null OR Bowling_skill is null;

-- city table
SELECT * FROM city where City_Id is null OR City_Name is null OR Country_id is null;

-- country table
SELECT * FROM country where Country_Id is null OR Country_Name is null;

-- extra_runs table
SELECT * FROM extra_runs where Match_Id is null OR Over_Id is null OR Ball_Id is null OR
 Extra_Type_Id is null OR Extra_Runs is null OR Innings_No is null;

-- extra_type table
SELECT * FROM extra_type where Extra_Id is null OR Extra_Name is null;

-- matches table
SELECT * FROM matches where Match_Id is null or Team_1 is null or Team_2 is null or Match_Date is null  
	or Season_Id is null or Venue_Id is null or Toss_Winner is null or Toss_Decide is null or
    Win_Type is null or Win_Margin is null or Outcome_type is null or Match_Winner is null or
    Man_of_the_Match is null;
    
-- out_type table
SELECT * FROM out_type where Out_Id is null or Out_Name is null;

-- outcome table
SELECT * FROM outcome where Outcome_Id is null or Outcome_Type is null;

-- player table
SELECT * FROM player where Player_Id is null or Player_Name is null or DOB is null or Batting_hand is null
	or Bowling_skill is null or Country_Name is null;
    
-- null values replaced with 0 
UPDATE player
SET bowling_skill = 0
WHERE bowling_skill IS NULL;    
    
-- player_match
SELECT * FROM player_match where Match_Id is null or Player_Id is null or Role_Id is null or Team_Id is null;

-- rolee
SELECT * FROM rolee where Role_Id is null or Role_Desc is null;

-- season
SELECT * FROM season where Season_Id is null or Man_of_the_Series is null or Orange_Cap is null or
	Purple_Cap is null or Season_Year is null;
    
-- sysdiagrams
SELECT * FROM sysdiagrams where name is null or principal_id is null or diagram_id is null or
	version is null or definition is null;
    
-- team
SELECT * FROM team where Team_Id is null or Team_Name is null;

-- toss_decision
SELECT * FROM team where Team_Id is null or Team_Name is null;

-- umpire
SELECT * FROM umpire where Umpire_Id is null or Umpire_Name is null or Umpire_Country is null;

-- venue
SELECT * FROM venue where Venue_Id is null or Venue_Name is null or City_Id is null;

-- wicket_taken
SELECT * FROM wicket_taken where Match_Id is null or Over_Id is null or Ball_Id is null or Player_Out is null or
	Kind_Out is null or Fielders is null or Innings_No is null;
    
-- null values replaced with o (Zero) wickets taken
UPDATE wicket_taken
SET Fielders = 0  -- or 'Not Applicable'
WHERE Fielders IS NULL 
  AND Kind_Out IN (SELECT Out_Id FROM out_type WHERE Out_Name IN 
  ('bowled', 'lbw', 'retired hurt', 'caught and bowled','hit wicket','run out','obstructing the field'));
    
-- win_by
SELECT * FROM win_by where Win_Id is null or Win_Type is null;

-- null values tables - matches,player,wicket taken 
UPDATE wicket_taken
SET Fielders = 0  -- or 'Not Applicable'
WHERE Fielders IS NULL 
  AND Kind_Out IN (SELECT Out_Id FROM out_type WHERE Out_Name IN 
  ('bowled', 'lbw', 'retired hurt', 'caught and bowled','hit wicket','run out','obstructing the field'));

-- 1.List the different dtypes of columns in table “ball_by_ball” 
-- (using information schema)

SELECT COLUMN_NAME, DATA_TYPE
FROM information_schema.COLUMNS
WHERE TABLE_NAME = 'ball_by_ball';


-- 2.What is the total number of run scored in 1st season by RCB 
-- (bonus : also include the extra runs using the extra runs table)

SELECT SUM(bs.Runs_Scored) AS total_runs,
    SUM(er.Extra_Runs) AS total_extra_runs,
    SUM(bs.Runs_Scored) + SUM(er.Extra_Runs) AS grand_total_runs
FROM ball_by_ball AS bbb
LEFT JOIN batsman_scored AS bs ON bbb.Ball_Id = bs.Ball_Id AND bbb.Match_Id = bs.Match_Id 
        AND bbb.Over_Id = bs.Over_Id AND bbb.Innings_No = bs.Innings_No
LEFT JOIN extra_runs AS er ON er.Ball_Id = bbb.Ball_Id AND er.Match_Id = bbb.Match_Id 
        AND er.Over_Id = bbb.Over_Id AND er.Innings_No = bbb.Innings_No
JOIN matches AS m ON m.Match_Id = bbb.Match_Id WHERE m.Season_Id = 1 
    AND (SELECT Team_Id FROM team WHERE Team_Name = 'Royal Challengers Bangalore') IN (m.Team_1, m.Team_2);


-- 3.How many players were more than age of 25 during season 2 ?

SELECT count(*) as Count_Of_Players_Above_25_Years_Old FROM player
WHERE (SELECT Season_Year FROM season WHERE Season_Id=2)-YEAR(DOB) > 25;

-- 4.How many matches did RCB win in season 1 ?
    
SELECT COUNT(*) AS Count_Of_RCB_Matches_In_Season1,
    SUM(CASE WHEN Match_Winner = (SELECT Team_Id FROM team WHERE Team_Name = 'Royal Challengers Bangalore') 
        THEN 1 ELSE 0 END) AS Count_Of_RCB_Wins_In_Season1
FROM matches AS m WHERE m.Season_Id = 1 
    AND (SELECT Team_Id FROM team WHERE Team_Name = 'Royal Challengers Bangalore') IN (m.Team_1, m.Team_2);

-- 5.List top 10 players according to their strike rate in last 4 seasons

WITH LastFourSeasons AS (
    SELECT Season_Id
    FROM season
    ORDER BY Season_Year DESC
    LIMIT 4
),

Player_With_Total_Runs_And_Total_Balls as (
SELECT p.Player_ID, p.Player_Name,
	coalesce(SUM(bs.Runs_Scored),0)+coalesce(sum(er.Extra_Runs),0) as Total_Runs,
    coalesce(COUNT(bs.Ball_Id),0)+coalesce(count(er.Ball_Id)) AS Total_Balls
FROM ball_by_ball AS bbb
LEFT JOIN batsman_scored AS bs ON bbb.Ball_Id = bs.Ball_Id AND bbb.Match_Id = bs.Match_Id 
        AND bbb.Over_Id = bs.Over_Id AND bbb.Innings_No = bs.Innings_No
LEFT JOIN extra_runs AS er ON er.Ball_Id = bbb.Ball_Id AND er.Match_Id = bbb.Match_Id 
        AND er.Over_Id = bbb.Over_Id AND er.Innings_No = bbb.Innings_No
JOIN matches AS m ON bbb.Match_Id = m.Match_Id
JOIN player as p ON p.Player_Id=bbb.Striker
WHERE m.Season_Id IN (SELECT Season_Id FROM LastFourSeasons)
GROUP BY p.Player_ID, p.Player_Name)

select Player_Id,Player_Name,Total_Runs,Total_Balls,((Total_Runs/Total_Balls)*100) as Strike_Rate
from Player_With_Total_Runs_And_Total_Balls
order by Total_Runs desc limit 10;


-- 6.What is the average runs scored by each batsman considering all the seasons?

SELECT p.Player_ID, p.Player_Name,
	round(coalesce(avg(bs.Runs_Scored),0)+coalesce(avg(er.Extra_Runs),0),2) as Average_Runs
FROM ball_by_ball AS bbb
LEFT JOIN batsman_scored AS bs ON bbb.Ball_Id = bs.Ball_Id AND bbb.Match_Id = bs.Match_Id 
        AND bbb.Over_Id = bs.Over_Id AND bbb.Innings_No = bs.Innings_No
LEFT JOIN extra_runs AS er ON er.Ball_Id = bbb.Ball_Id AND er.Match_Id = bbb.Match_Id 
        AND er.Over_Id = bbb.Over_Id AND er.Innings_No = bbb.Innings_No
LEFT JOIN player as p ON p.Player_Id=bbb.Striker
GROUP BY p.Player_ID, p.Player_Name
order by Average_Runs desc;


-- 7.What are the average wickets taken by each bowler considering all the seasons?

with Players_With_Wicket_Count_By_Season as (
	SELECT p.Player_ID, p.Player_Name,Season_Id,count(Bowler) as total_wicket_count
	FROM wicket_taken AS w
	JOIN ball_by_ball AS bbb ON bbb.Ball_Id = w.Ball_Id AND bbb.Match_Id = w.Match_Id 
        AND bbb.Over_Id = w.Over_Id AND bbb.Innings_No = w.Innings_No
	join matches as m on m.Match_Id=bbb.Match_Id
	JOIN player as p ON p.Player_Id=bbb.Bowler
	GROUP BY p.Player_ID, p.Player_Name,Season_Id 
)


select Player_ID,Player_Name,sum(total_wicket_count) as total_wicket_count,
	round(avg(total_wicket_count),2) as avg_wickets 
from Players_With_Wicket_Count_By_Season
group by Player_Id,Player_Name order by 3 desc;


-- 8.List all the players who have average runs scored greater than overall average and 
--    who have taken wickets greater than overall average

with Players_Average_Runs as (
SELECT p.Player_ID, p.Player_Name,
	round(coalesce(avg(bs.Runs_Scored),0)+coalesce(avg(er.Extra_Runs),0),2) as Average_Runs
FROM ball_by_ball AS bbb
LEFT JOIN batsman_scored AS bs ON bbb.Ball_Id = bs.Ball_Id AND bbb.Match_Id = bs.Match_Id 
        AND bbb.Over_Id = bs.Over_Id AND bbb.Innings_No = bs.Innings_No
LEFT JOIN extra_runs AS er ON er.Ball_Id = bbb.Ball_Id AND er.Match_Id = bbb.Match_Id 
        AND er.Over_Id = bbb.Over_Id AND er.Innings_No = bbb.Innings_No
LEFT JOIN player as p ON p.Player_Id=bbb.Striker
GROUP BY p.Player_ID, p.Player_Name
order by Average_Runs desc
),

Players_Average_Wickets as (
with Players_With_Wicket_Count_By_Season as (
	SELECT p.Player_ID, p.Player_Name,Season_Id,count(Bowler) as total_wicket_count
	FROM wicket_taken AS w
	JOIN ball_by_ball AS bbb ON bbb.Ball_Id = w.Ball_Id AND bbb.Match_Id = w.Match_Id 
        AND bbb.Over_Id = w.Over_Id AND bbb.Innings_No = w.Innings_No
	join matches as m on m.Match_Id=bbb.Match_Id
	JOIN player as p ON p.Player_Id=bbb.Bowler
	GROUP BY p.Player_ID, p.Player_Name,Season_Id 
)
select Player_ID,Player_Name,sum(total_wicket_count) as total_wicket_count,
	round(avg(total_wicket_count),2) as avg_wickets 
from Players_With_Wicket_Count_By_Season
group by Player_Id,Player_Name order by 3 desc
),

Runs_Overall_Average as (
select round(avg(Average_Runs),0) as Overall_Runs_Average from Players_Average_Runs
),

Wickets_Overall_Average as (
select round(avg(avg_wickets),2) as Overall_Wickets_Average from Players_Average_Wickets
)

select r.Player_ID,r.Player_Name,Average_Runs,avg_Wickets from Players_Average_Runs as r
join Players_Average_Wickets as w on w.Player_ID=r.Player_ID
where Average_Runs >(select Overall_Runs_Average from Runs_Overall_Average) and 
	avg_Wickets>(select Overall_Wickets_Average from Wickets_Overall_Average)
order by 3 desc,4 desc;

-- 9.Create a table rcb_record table that shows wins and losses of RCB in an individual venue.

DROP TABLE IF EXISTS rcb_record;
CREATE TABLE rcb_record AS (
	WITH RCB_Played_Matches as (
		SELECT * FROM matches as m 
		WHERE (SELECT Team_Id FROM team WHERE Team_Name = 'Royal Challengers Bangalore') IN (m.Team_1, m.Team_2)
	)
	select a.Venue_Id,Venue_Name,
		sum(case when Match_Winner=(SELECT Team_Id FROM team WHERE Team_Name = 'Royal Challengers Bangalore')
			then 1 else 0 end) as Wins,
		sum(case when Match_Winner!=(SELECT Team_Id FROM team WHERE Team_Name = 'Royal Challengers Bangalore')
			then 1 else 0 end) as Losses from RCB_Played_Matches as a
	join venue as v on v.Venue_Id=a.Venue_Id
	group by Venue_Id
);

select * from rcb_record order by wins desc;

-- 10.What is the impact of bowling style on wickets taken

WITH Wicket_Count_By_Bowling_Style as (
	SELECT  bs.Bowling_skill,count(Bowler) as Wicket_Count FROM wicket_taken AS w
	JOIN ball_by_ball AS bbb ON bbb.Ball_Id = w.Ball_Id AND bbb.Match_Id = w.Match_Id 
			AND bbb.Over_Id = w.Over_Id AND bbb.Innings_No = w.Innings_No
	JOIN player AS p ON p.Player_Id=bbb.Bowler
	JOIN bowling_style as bs on bs.Bowling_Id=p.Bowling_skill
	GROUP BY 1
),

Wicket_Count_Average_By_Bowling_Style as (
	select round(avg(Wicket_Count),2) as Overall_Avg from Wicket_Count_By_Bowling_Style
)

select * from Wicket_Count_By_Bowling_Style
order by Wicket_Count desc;

-- 11.Write the sql query to provide a status of whether the performance of the team better than the 
-- previous year performance on the basis of number of runs scored by the team in the season and 
-- number of wickets taken

WITH Total_Team_Runs_By_Season_Year as (
SELECT pm.Team_Id,Season_Year,
	round(coalesce(sum(bs.Runs_Scored),0)+coalesce(sum(er.Extra_Runs),0),2) as Curr_Year_Total_Runs,
    coalesce(lag(round(coalesce(sum(bs.Runs_Scored),0)+coalesce(sum(er.Extra_Runs),0),2)) over 
		(partition by pm.Team_Id order by Season_Year),0) as Prev_Year_Total_Runs
FROM ball_by_ball AS bbb
LEFT JOIN batsman_scored AS bs ON bbb.Ball_Id = bs.Ball_Id AND bbb.Match_Id = bs.Match_Id 
        AND bbb.Over_Id = bs.Over_Id AND bbb.Innings_No = bs.Innings_No
LEFT JOIN extra_runs AS er ON er.Ball_Id = bbb.Ball_Id AND er.Match_Id = bbb.Match_Id 
        AND er.Over_Id = bbb.Over_Id AND er.Innings_No = bbb.Innings_No
LEFT JOIN player as p ON p.Player_Id=bbb.Striker
join matches as m on m.Match_Id=bbb.Match_Id
join season as s on s.Season_Id=m.Season_Id
join player_match as pm on pm.Player_Id=bbb.Striker and pm.Match_Id=bbb.Match_Id
GROUP BY pm.Team_Id,Season_Year
),

Team_Wicket_Count_By_Season_Year as (
	SELECT pm.Team_Id,Season_Year,count(Bowler) as Curr_Year_Wicket_Count,
		coalesce(lag(count(Bowler)) over(partition by Team_Id order by Season_Year asc),0) as Prev_Year_Wicket_Count
	FROM wicket_taken AS w
	JOIN ball_by_ball AS bbb ON bbb.Ball_Id = w.Ball_Id AND bbb.Match_Id = w.Match_Id 
        AND bbb.Over_Id = w.Over_Id AND bbb.Innings_No = w.Innings_No
	join matches as m on m.Match_Id=bbb.Match_Id
	JOIN player as p ON p.Player_Id=bbb.Bowler
    join player_match as pm on pm.Match_Id=bbb.Match_Id and pm.Player_Id=bbb.Bowler
    join season as s on s.Season_Id=m.Season_Id
	GROUP BY pm.Team_Id,Season_Year
)

select r.Team_Id,Team_Name,r.Season_Year,
	(case when Curr_Year_Total_Runs>Prev_Year_Total_Runs and Curr_Year_Wicket_Count>Prev_Year_Wicket_Count
		then 'Better'
        when Curr_Year_Total_Runs=Prev_Year_Total_Runs and Curr_Year_Wicket_Count=Prev_Year_Wicket_Count
        then 'Same' else 'Worse' end) as Performance
from Total_Team_Runs_By_Season_Year as r
join Team_Wicket_Count_By_Season_Year as w on w.Team_Id=r.Team_Id and w.Season_Year=r.Season_Year
join team as t on t.Team_Id=r.Team_Id
where r.Season_Year=(select max(Season_Year) from Team_Wicket_Count_By_Season_Year);

-- 12.	Can you derive more KPIs for the team strategy if possible?

-- Caughts by fielders
SELECT Player_Name,count(*) as Number_Of_Caughts FROM wicket_taken as wt
join player as p on p.Player_ID=wt.Fielders
where Fielders !=0
group by Fielders  
order by 2 desc;
 
-- number of outs
SELECT Player_Name,count(*) as Number_Of_outs FROM wicket_taken as wt
join player as p on p.Player_ID=wt.Player_Out
group by Player_Name
order by 2 desc;

-- 13.Using SQL, write a query to find out average wickets taken by each bowler in each venue.
-- Also rank the gender according to the average value. 
 
 with Players_With_Wicket_Count_By_Season as (
	SELECT p.Player_ID, p.Player_Name,Season_Id,Venue_Id,count(Bowler) as total_wicket_count
	FROM wicket_taken AS w
	JOIN ball_by_ball AS bbb ON bbb.Ball_Id = w.Ball_Id AND bbb.Match_Id = w.Match_Id 
        AND bbb.Over_Id = w.Over_Id AND bbb.Innings_No = w.Innings_No
	join matches as m on m.Match_Id=bbb.Match_Id
	JOIN player as p ON p.Player_Id=bbb.Bowler
	GROUP BY p.Player_ID, p.Player_Name,Season_Id,Venue_Id
)
select Player_ID as Bowler_Id,Venue_Id,Player_Name as Bowler_Name,
	sum(total_wicket_count) as Total_Wicket_Count,round(avg(total_wicket_count),2) as avg_wickets,
    dense_rank() over(order by round(avg(total_wicket_count),2) desc) as Bowler_Rank 
from Players_With_Wicket_Count_By_Season
group by Venue_Id,Player_Id,Player_Name order by Bowler_Rank;

-- 14.	Which of the given players have consistently performed well in past seasons? 
-- (will you use any visualisation to solve the problem)
WITH Batsman_Performance AS (
    SELECT p.Player_ID, p.Player_Name, s.Season_Year,
           SUM(bs.Runs_Scored + COALESCE(er.Extra_Runs, 0)) AS Total_Runs,  -- Adding extra runs
           COUNT(DISTINCT m.Match_Id) AS Matches_Played,
           ROUND(SUM(bs.Runs_Scored + COALESCE(er.Extra_Runs, 0)) / COUNT(DISTINCT m.Match_Id), 2) AS Avg_Runs_Per_Match
    FROM ball_by_ball AS bbb
    JOIN batsman_scored AS bs ON bbb.Ball_Id = bs.Ball_Id 
                              AND bbb.Match_Id = bs.Match_Id 
                              AND bbb.Over_Id = bs.Over_Id 
                              AND bbb.Innings_No = bs.Innings_No
    JOIN player AS p ON p.Player_Id = bbb.Striker
    JOIN matches AS m ON m.Match_Id = bbb.Match_Id
    JOIN season AS s ON s.Season_Id = m.Season_Id
    LEFT JOIN extra_runs AS er ON bbb.Match_Id = er.Match_Id 
                               AND bbb.Ball_Id = er.Ball_Id
                               AND bbb.Over_Id = er.Over_Id
                               AND bbb.Innings_No = er.Innings_No
    GROUP BY p.Player_ID, p.Player_Name, s.Season_Year
),
Consistent_Batsmen AS (
    SELECT Player_ID, Player_Name,
           ROUND(AVG(Avg_Runs_Per_Match), 2) AS Avg_Runs_Overall,
           MAX(Avg_Runs_Per_Match) - MIN(Avg_Runs_Per_Match) AS Performance_Variation
    FROM Batsman_Performance
    GROUP BY Player_ID, Player_Name
    HAVING Performance_Variation < 10  -- Players with stable performance (variation < 10 runs)
)
SELECT * FROM Consistent_Batsmen
ORDER BY Avg_Runs_Overall DESC;

-- bowlers Performance
WITH Bowler_Performance AS (
    SELECT p.Player_ID, p.Player_Name, s.Season_Year,
           COUNT(bbb.Bowler) AS Total_Wickets,
           COUNT(DISTINCT m.Match_Id) AS Matches_Played,
           ROUND(COUNT(bbb.Bowler) / COUNT(DISTINCT m.Match_Id), 2) AS Avg_Wickets_Per_Match
    FROM wicket_taken AS w
    JOIN ball_by_ball AS bbb ON w.Ball_Id = bbb.Ball_Id 
                             AND w.Match_Id = bbb.Match_Id 
                             AND w.Over_Id = bbb.Over_Id 
                             AND w.Innings_No = bbb.Innings_No
    JOIN player AS p ON p.Player_Id = bbb.Bowler
    JOIN matches AS m ON m.Match_Id = w.Match_Id
    JOIN season AS s ON s.Season_Id = m.Season_Id
    GROUP BY p.Player_ID, p.Player_Name, s.Season_Year
),
Consistent_Bowlers AS (
    SELECT Player_ID, Player_Name,
           ROUND(AVG(Avg_Wickets_Per_Match), 2) AS Avg_Wickets_Overall,
           MAX(Avg_Wickets_Per_Match) - MIN(Avg_Wickets_Per_Match) AS Performance_Variation
    FROM Bowler_Performance
    GROUP BY Player_ID, Player_Name
    HAVING Performance_Variation < 1  -- Bowlers with stable performance (variation < 1 wicket)
)
SELECT * FROM Consistent_Bowlers
ORDER BY Avg_Wickets_Overall DESC;

-- 15.	Are there players whose performance is more suited to 
-- specific venues or conditions? (how would you present this using charts?) 

WITH Player_Performance_By_Venue AS (
    SELECT p.Player_ID, p.Player_Name, v.Venue_Name,
           SUM(bs.Runs_Scored + COALESCE(er.Extra_Runs, 0)) AS Total_Runs,
           COUNT(DISTINCT m.Match_Id) AS Matches_Played,
           ROUND(SUM(bs.Runs_Scored + COALESCE(er.Extra_Runs, 0)) / COUNT(DISTINCT m.Match_Id), 2) AS Avg_Runs_Per_Match
    FROM ball_by_ball AS bbb
    JOIN batsman_scored AS bs ON bbb.Ball_Id = bs.Ball_Id 
                              AND bbb.Match_Id = bs.Match_Id 
                              AND bbb.Over_Id = bs.Over_Id 
                              AND bbb.Innings_No = bs.Innings_No
    JOIN player AS p ON p.Player_Id = bbb.Striker
    JOIN matches AS m ON m.Match_Id = bbb.Match_Id
    JOIN venue AS v ON v.Venue_Id = m.Venue_Id
    LEFT JOIN extra_runs AS er ON bbb.Match_Id = er.Match_Id 
                               AND bbb.Ball_Id = er.Ball_Id
                               AND bbb.Over_Id = er.Over_Id
                               AND bbb.Innings_No = er.Innings_No
    GROUP BY p.Player_ID, p.Player_Name, v.Venue_Name
)
SELECT * FROM Player_Performance_By_Venue
ORDER BY Total_Runs DESC;


-- 1.	How does toss decision have affected the result of the match ? 
-- (which visualisations could be used to better present your answer)
-- And is the impact limited to only specific venues?

WITH Toss_Outcome AS (
    SELECT m.Venue_Id,v.Venue_Name,m.Toss_Winner,m.Toss_Decide,m.Match_Winner,
        CASE WHEN m.Toss_Winner = m.Match_Winner THEN 'Won After Toss' 
            ELSE 'Lost After Toss' END AS Toss_Impact
    FROM matches AS m
    JOIN venue AS v ON m.Venue_Id = v.Venue_Id
)
SELECT  Toss_Impact, COUNT(*) AS Matches_Count
FROM Toss_Outcome
GROUP BY  Toss_Impact
ORDER BY  Toss_Impact;

-- 2.Suggest some of the players who would be best fit for the team?

-- batting strike rate and batting average
with Players_Batting_Strike_Rate as (
SELECT Player_Name, Strike_Rate, Total_Runs, Matches_Played, Batting_Avg, Boundary_Percentage
FROM (
    SELECT p.Player_ID, p.Player_Name, 
           ROUND((SUM(bs.Runs_Scored) + COALESCE(SUM(er.Extra_Runs), 0)) * 100.0 / NULLIF(COUNT(bs.Ball_Id) + COALESCE(COUNT(er.Ball_Id), 0), 0), 2) AS Strike_Rate,
           SUM(bs.Runs_Scored + COALESCE(er.Extra_Runs, 0)) AS Total_Runs,
           COUNT(DISTINCT m.Match_Id) AS Matches_Played,
           ROUND((SUM(bs.Runs_Scored) + COALESCE(SUM(er.Extra_Runs), 0)) /count(distinct m.Match_Id), 2) AS Batting_Avg,
           ROUND(SUM(CASE WHEN (bs.Runs_Scored + COALESCE(er.Extra_Runs, 0)) IN (4, 6) THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(bs.Ball_Id) + COALESCE(COUNT(er.Ball_Id), 0), 0), 2) AS Boundary_Percentage
    FROM ball_by_ball AS bbb
    LEFT JOIN extra_runs AS er ON er.Ball_Id = bbb.Ball_Id 
                               AND er.Match_Id = bbb.Match_Id 
                               AND er.Over_Id = bbb.Over_Id
    JOIN batsman_scored AS bs ON bbb.Ball_Id = bs.Ball_Id 
                              AND bbb.Match_Id = bs.Match_Id 
                              AND bbb.Over_Id = bs.Over_Id
    JOIN player AS p ON p.Player_ID = bbb.Striker
    JOIN matches AS m ON m.Match_Id = bbb.Match_Id
    GROUP BY p.Player_ID, p.Player_Name
) AS Batting_Stats
ORDER BY 3 desc,Strike_Rate DESC, Boundary_Percentage DESC
),
-- Bowlers strike rate and avg wickets
Players_With_Wicket_Count_By_Match as (
	SELECT p.Player_ID, p.Player_Name,m.Match_Id,count(Bowler) as total_wicket_count
	FROM wicket_taken AS w
	JOIN ball_by_ball AS bbb ON bbb.Ball_Id = w.Ball_Id AND bbb.Match_Id = w.Match_Id 
        AND bbb.Over_Id = w.Over_Id AND bbb.Innings_No = w.Innings_No
	join matches as m on m.Match_Id=bbb.Match_Id
	JOIN player as p ON p.Player_Id=bbb.Bowler
	GROUP BY p.Player_ID, p.Player_Name,m.Match_Id 
),

Players_With_Total_Balls_Bowled as (
	SELECT p.Player_ID, p.Player_Name,m.Match_Id,count(Bowler) as total_ball_count
	FROM ball_by_ball AS bbb
	join matches as m on m.Match_Id=bbb.Match_Id
	JOIN player as p ON p.Player_Id=bbb.Bowler
	GROUP BY p.Player_ID, p.Player_Name,m.Match_Id 
),

Bowlers_Strike_Rate_By_Match as (
select ptb.Player_Name,ptb.Match_Id,total_ball_count,total_wicket_count,
	round(total_ball_count/total_wicket_count,2) as strike_rate from Players_With_Total_Balls_Bowled as ptb
join Players_With_Wicket_Count_By_Match as pwc on pwc.Player_ID=ptb.Player_ID and pwc.Match_Id=ptb.Match_Id
order by 4 desc
),

Bowlers_with_Strike_Rate as (
select * from (
	select Player_Name,sum(total_ball_count) as total_bowled_balls,sum(total_wicket_count) as total_wickets,
		round(sum(total_ball_count)/sum(total_wicket_count),2) as strike_rate from Bowlers_Strike_Rate_By_Match
	group by Player_Name ) as a
order by total_wickets desc
),

All_Rounders as (
select a.Player_Name,Total_Runs,Matches_Played,Batting_Avg,a.Strike_Rate as batting_strike_rate,
	total_bowled_balls,total_wickets,b.strike_rate as bowling_strike_rate from Players_Batting_Strike_Rate as a
join Bowlers_with_Strike_Rate as b on b.Player_Name=a.Player_Name
order by 2 desc,6 desc
)

-- all rounders
-- select * from All_Rounders
-- where Total_Runs>1000 and total_wickets>100;

-- Bowlers
select * from Bowlers_with_Strike_Rate
where total_wickets>100 and strike_rate<15;

-- Players for batting
-- select * from Players_Batting_Strike_Rate
-- WHERE Strike_Rate > 130 AND Matches_Played > 10 AND Batting_Avg > 30 and Player_Name not in (select Player_Name from Bowlers_with_Strike_Rate);


-- 3.What are some of parameters that should be focused while selecting the players?

-- batting strike rate and batting average
with Players_Batting_Strike_Rate as (
SELECT Player_Name, Strike_Rate, Total_Runs, Matches_Played, Batting_Avg, Boundary_Percentage
FROM (
    SELECT p.Player_ID, p.Player_Name, 
           ROUND((SUM(bs.Runs_Scored) + COALESCE(SUM(er.Extra_Runs), 0)) * 100.0 / NULLIF(COUNT(bs.Ball_Id) + COALESCE(COUNT(er.Ball_Id), 0), 0), 2) AS Strike_Rate,
           SUM(bs.Runs_Scored + COALESCE(er.Extra_Runs, 0)) AS Total_Runs,
           COUNT(DISTINCT m.Match_Id) AS Matches_Played,
           ROUND((SUM(bs.Runs_Scored) + COALESCE(SUM(er.Extra_Runs), 0)) /count(distinct m.Match_Id), 2) AS Batting_Avg,
           ROUND(SUM(CASE WHEN (bs.Runs_Scored + COALESCE(er.Extra_Runs, 0)) IN (4, 6) THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(bs.Ball_Id) + COALESCE(COUNT(er.Ball_Id), 0), 0), 2) AS Boundary_Percentage
    FROM ball_by_ball AS bbb
    LEFT JOIN extra_runs AS er ON er.Ball_Id = bbb.Ball_Id 
                               AND er.Match_Id = bbb.Match_Id 
                               AND er.Over_Id = bbb.Over_Id
    JOIN batsman_scored AS bs ON bbb.Ball_Id = bs.Ball_Id 
                              AND bbb.Match_Id = bs.Match_Id 
                              AND bbb.Over_Id = bs.Over_Id
    JOIN player AS p ON p.Player_ID = bbb.Striker
    JOIN matches AS m ON m.Match_Id = bbb.Match_Id
    GROUP BY p.Player_ID, p.Player_Name
) AS Batting_Stats
ORDER BY 3 desc,Strike_Rate DESC, Boundary_Percentage DESC
),
-- Bowlers strike rate and avg wickets
Players_With_Wicket_Count_By_Match as (
	SELECT p.Player_ID, p.Player_Name,m.Match_Id,count(Bowler) as total_wicket_count
	FROM wicket_taken AS w
	JOIN ball_by_ball AS bbb ON bbb.Ball_Id = w.Ball_Id AND bbb.Match_Id = w.Match_Id 
        AND bbb.Over_Id = w.Over_Id AND bbb.Innings_No = w.Innings_No
	join matches as m on m.Match_Id=bbb.Match_Id
	JOIN player as p ON p.Player_Id=bbb.Bowler
	GROUP BY p.Player_ID, p.Player_Name,m.Match_Id 
),

Players_With_Total_Balls_Bowled as (
	SELECT p.Player_ID, p.Player_Name,m.Match_Id,count(Bowler) as total_ball_count
	FROM ball_by_ball AS bbb
	join matches as m on m.Match_Id=bbb.Match_Id
	JOIN player as p ON p.Player_Id=bbb.Bowler
	GROUP BY p.Player_ID, p.Player_Name,m.Match_Id 
),

Bowlers_Strike_Rate_By_Match as (
select ptb.Player_Name,ptb.Match_Id,total_ball_count,total_wicket_count,
	round(total_ball_count/total_wicket_count,2) as strike_rate from Players_With_Total_Balls_Bowled as ptb
join Players_With_Wicket_Count_By_Match as pwc on pwc.Player_ID=ptb.Player_ID and pwc.Match_Id=ptb.Match_Id
order by 4 desc
),

Bowlers_with_Strike_Rate as (
select * from (
	select Player_Name,sum(total_ball_count) as total_bowled_balls,sum(total_wicket_count) as total_wickets,
		round(sum(total_ball_count)/sum(total_wicket_count),2) as strike_rate from Bowlers_Strike_Rate_By_Match
	group by Player_Name ) as a
where total_wickets>100 and strike_rate<15
order by total_wickets desc
),

All_Rounders as (
select a.Player_Name,Total_Runs,Matches_Played,Batting_Avg,a.Strike_Rate as batting_strike_rate,
	total_bowled_balls,total_wickets,b.strike_rate as bowling_strike_rate from Players_Batting_Strike_Rate as a
join Bowlers_with_Strike_Rate as b on b.Player_Name=a.Player_Name
order by 2 desc,6 desc
)

-- all rounders
-- select * from All_Rounders;

-- Bowlers
select * from Bowlers_with_Strike_Rate;

-- Players for batting
-- select * from Players_Batting_Strike_Rate;
    

-- 4.Which players offer versatility in their skills and can contribute effectively 
-- with both bat and ball? (can you visualize the data for the same)

with Players_With_Total_Runs as (
SELECT p.Player_ID, p.Player_Name,
	round(coalesce(sum(bs.Runs_Scored),0)+coalesce(sum(er.Extra_Runs),0),2) as Total_Runs
FROM ball_by_ball AS bbb
LEFT JOIN batsman_scored AS bs ON bbb.Ball_Id = bs.Ball_Id AND bbb.Match_Id = bs.Match_Id 
        AND bbb.Over_Id = bs.Over_Id AND bbb.Innings_No = bs.Innings_No
LEFT JOIN extra_runs AS er ON er.Ball_Id = bbb.Ball_Id AND er.Match_Id = bbb.Match_Id 
        AND er.Over_Id = bbb.Over_Id AND er.Innings_No = bbb.Innings_No
LEFT JOIN player as p ON p.Player_Id=bbb.Striker
GROUP BY p.Player_ID, p.Player_Name
order by 3 desc
),

Players_With_Wicket_Count as (
	SELECT p.Player_ID, p.Player_Name,count(Bowler) as Total_Wicket_Count
	FROM wicket_taken AS w
	JOIN ball_by_ball AS bbb ON bbb.Ball_Id = w.Ball_Id AND bbb.Match_Id = w.Match_Id 
        AND bbb.Over_Id = w.Over_Id AND bbb.Innings_No = w.Innings_No
	join matches as m on m.Match_Id=bbb.Match_Id
	JOIN player as p ON p.Player_Id=bbb.Bowler
	GROUP BY p.Player_ID, p.Player_Name
)

select r.Player_ID,r.Player_Name,Total_Wicket_Count,Total_Runs from Players_With_Wicket_Count as w
join Players_With_Total_Runs as r on r.Player_ID=w.Player_ID
where Total_Wicket_Count > 50 and Total_Runs >1000
order by 3 desc;

-- 5.Are there players whose presence positively influences the morale and
--  performance of the team? (justify your answer using visualisation)

with Players_Wins_And_Lost as (
select p.Player_Name,count(distinct m.Match_Id) as Matches_Played,
	count(case when m.Match_Winner=pm.Team_Id then 1 end) as Matches_Won,
    count(case when m.Match_Winner!=pm.Team_Id then 1 end) as Matches_Lost
    from player as p
join player_match as pm on pm.Player_ID=p.Player_ID
join matches as m on m.Match_Id = pm.Match_Id and pm.Team_Id in (m.Team_1,m.Team_2)
group by p.Player_Name
order by Matches_Won desc
),

-- Man of the match
Man_Of_The_Match as (
SELECT p.Player_Name, COUNT(coalesce(Man_of_the_Match,0)) AS Man_Of_The_Match_Count
FROM matches AS m
JOIN player AS p ON m.Man_of_the_Match = p.Player_ID
GROUP BY p.Player_Name
)

select w.*,Man_Of_The_Match_Count from Players_Wins_And_Lost as w
join Man_Of_The_Match as m on m.Player_Name=w.Player_Name
where Man_Of_The_Match_Count > 10
order by 3 desc;


-- 6.What would you suggest to RCB before going to mega auction 
  WITH Total_Team_Runs_By_Season_Year as (
SELECT pm.Team_Id,Season_Year,
	round(coalesce(sum(bs.Runs_Scored),0)+coalesce(sum(er.Extra_Runs),0),2) as Curr_Year_Total_Runs,
    coalesce(lag(round(coalesce(sum(bs.Runs_Scored),0)+coalesce(sum(er.Extra_Runs),0),2)) over 
		(partition by pm.Team_Id order by Season_Year),0) as Prev_Year_Total_Runs
FROM ball_by_ball AS bbb
LEFT JOIN batsman_scored AS bs ON bbb.Ball_Id = bs.Ball_Id AND bbb.Match_Id = bs.Match_Id 
        AND bbb.Over_Id = bs.Over_Id AND bbb.Innings_No = bs.Innings_No
LEFT JOIN extra_runs AS er ON er.Ball_Id = bbb.Ball_Id AND er.Match_Id = bbb.Match_Id 
        AND er.Over_Id = bbb.Over_Id AND er.Innings_No = bbb.Innings_No
LEFT JOIN player as p ON p.Player_Id=bbb.Striker
join matches as m on m.Match_Id=bbb.Match_Id
join season as s on s.Season_Id=m.Season_Id
join player_match as pm on pm.Player_Id=bbb.Striker and pm.Match_Id=bbb.Match_Id
GROUP BY pm.Team_Id,Season_Year
),

Team_Wicket_Count_By_Season_Year as (
	SELECT pm.Team_Id,Season_Year,count(Bowler) as Curr_Year_Wicket_Count,
		coalesce(lag(count(Bowler)) over(partition by Team_Id order by Season_Year asc),0) as Prev_Year_Wicket_Count
	FROM wicket_taken AS w
	JOIN ball_by_ball AS bbb ON bbb.Ball_Id = w.Ball_Id AND bbb.Match_Id = w.Match_Id 
        AND bbb.Over_Id = w.Over_Id AND bbb.Innings_No = w.Innings_No
	join matches as m on m.Match_Id=bbb.Match_Id
	JOIN player as p ON p.Player_Id=bbb.Bowler
    join player_match as pm on pm.Match_Id=bbb.Match_Id and pm.Player_Id=bbb.Bowler
    join season as s on s.Season_Id=m.Season_Id
	GROUP BY pm.Team_Id,Season_Year
)
select r.Team_Id,Team_Name,r.Season_Year,Curr_Year_Total_Runs as total_runs,
	Curr_Year_Wicket_Count as Wicket_Count, 
	(case when Curr_Year_Total_Runs>Prev_Year_Total_Runs and Curr_Year_Wicket_Count>Prev_Year_Wicket_Count
		then 'Better'
        when Curr_Year_Total_Runs=Prev_Year_Total_Runs and Curr_Year_Wicket_Count=Prev_Year_Wicket_Count
        then 'Same' else 'Worse' end) as Performance
from Total_Team_Runs_By_Season_Year as r
join Team_Wicket_Count_By_Season_Year as w on w.Team_Id=r.Team_Id and w.Season_Year=r.Season_Year
join team as t on t.Team_Id=r.Team_Id 
where t.Team_Id=2;
  
-- 7.	What do you think could be the factors contributing to 
-- the high-scoring matches and the impact on viewership and team strategies
  
  -- batsmen high scoring and bowlers bowling and homeground advantage
  with Players_Batting_Strike_Rate as (
SELECT Player_Name, Strike_Rate, Total_Runs, Matches_Played, Batting_Avg, Boundary_Percentage
FROM (
    SELECT p.Player_ID, p.Player_Name, 
           ROUND((SUM(bs.Runs_Scored) + COALESCE(SUM(er.Extra_Runs), 0)) * 100.0 / NULLIF(COUNT(bs.Ball_Id) + COALESCE(COUNT(er.Ball_Id), 0), 0), 2) AS Strike_Rate,
           SUM(bs.Runs_Scored + COALESCE(er.Extra_Runs, 0)) AS Total_Runs,
           COUNT(DISTINCT m.Match_Id) AS Matches_Played,
           ROUND((SUM(bs.Runs_Scored) + COALESCE(SUM(er.Extra_Runs), 0)) /count(distinct m.Match_Id), 2) AS Batting_Avg,
           ROUND(SUM(CASE WHEN (bs.Runs_Scored + COALESCE(er.Extra_Runs, 0)) IN (4, 6) THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(bs.Ball_Id) + COALESCE(COUNT(er.Ball_Id), 0), 0), 2) AS Boundary_Percentage
    FROM ball_by_ball AS bbb
    LEFT JOIN extra_runs AS er ON er.Ball_Id = bbb.Ball_Id 
                               AND er.Match_Id = bbb.Match_Id 
                               AND er.Over_Id = bbb.Over_Id
    JOIN batsman_scored AS bs ON bbb.Ball_Id = bs.Ball_Id 
                              AND bbb.Match_Id = bs.Match_Id 
                              AND bbb.Over_Id = bs.Over_Id
    JOIN player AS p ON p.Player_ID = bbb.Striker
    JOIN matches AS m ON m.Match_Id = bbb.Match_Id
    GROUP BY p.Player_ID, p.Player_Name
) AS Batting_Stats
ORDER BY 3 desc,Strike_Rate DESC, Boundary_Percentage DESC
)
select * from Players_Batting_Strike_Rate;
-- 8.	Analyze the impact of home ground advantage on team performance and 
-- identify strategies to maximize this advantage for RCB.
  
-- batting in home ground
WITH Player_Performance_By_Venue AS (
    SELECT t.Team_Name,v.Venue_Name,s.Season_Year,
           SUM(bs.Runs_Scored + COALESCE(er.Extra_Runs, 0)) AS Total_Runs,
           COUNT(DISTINCT m.Match_Id) AS Matches_Played,
           ROUND(SUM(bs.Runs_Scored + COALESCE(er.Extra_Runs, 0)) / COUNT(DISTINCT m.Match_Id), 2) AS Avg_Runs_Per_Match
    FROM ball_by_ball AS bbb
    JOIN batsman_scored AS bs ON bbb.Ball_Id = bs.Ball_Id 
                              AND bbb.Match_Id = bs.Match_Id 
                              AND bbb.Over_Id = bs.Over_Id 
                              AND bbb.Innings_No = bs.Innings_No
    JOIN player AS p ON p.Player_Id = bbb.Striker
    JOIN matches AS m ON m.Match_Id = bbb.Match_Id
    join season as s on s.Season_Id=m.Season_Id
    join player_match as pm on pm.Match_Id=m.Match_Id and pm.Player_ID=p.Player_ID
    join team as t on t.Team_Id=pm.Team_Id
    JOIN venue AS v ON v.Venue_Id = m.Venue_Id
    LEFT JOIN extra_runs AS er ON bbb.Match_Id = er.Match_Id 
                               AND bbb.Ball_Id = er.Ball_Id
                               AND bbb.Over_Id = er.Over_Id
                               AND bbb.Innings_No = er.Innings_No
    GROUP BY v.Venue_Name,Season_Year,Team_Name
),
Homeground_Batting_Performance as (
SELECT Venue_Name,sum(Total_Runs) as Total_Runs,sum(Matches_Played) as Matches_Played,
	round(avg(Avg_Runs_Per_Match)) as Avg_Runs_Per_Match FROM Player_Performance_By_Venue
where Team_Name="Royal Challengers Bangalore" and Venue_Name="M Chinnaswamy Stadium"
ORDER BY Total_Runs DESC
),
Home_Away_Ground_Batting_Performance as (
SELECT "Others" as Venue_Name,sum(Total_Runs) as Total_Runs,sum(Matches_Played) as Matches_Played,
	round(avg(Avg_Runs_Per_Match)) as Avg_Runs_Per_Match FROM Player_Performance_By_Venue
where Team_Name="Royal Challengers Bangalore" and Venue_Name!="M Chinnaswamy Stadium"
ORDER BY Total_Runs DESC
)

select * from Home_Away_Ground_Batting_Performance
union all
select * from Homeground_Batting_Performance;
  
-- bowling in home ground
WITH Player_Performance_By_Venue AS (
    SELECT t.Team_Name,v.Venue_Name,s.Season_Year,
           count(bbb.Bowler) AS Total_Wickets,
           COUNT(DISTINCT m.Match_Id) AS Matches_Played
    FROM ball_by_ball AS bbb
    JOIN wicket_taken AS wt ON bbb.Ball_Id = wt.Ball_Id 
                              AND bbb.Match_Id = wt.Match_Id 
                              AND bbb.Over_Id = wt.Over_Id 
                              AND bbb.Innings_No = wt.Innings_No
    JOIN player AS p ON p.Player_Id = bbb.Bowler
    JOIN matches AS m ON m.Match_Id = bbb.Match_Id
    join season as s on s.Season_Id=m.Season_Id
    join player_match as pm on pm.Match_Id=m.Match_Id and pm.Player_ID=p.Player_ID
    join team as t on t.Team_Id=pm.Team_Id
    JOIN venue AS v ON v.Venue_Id = m.Venue_Id
    GROUP BY v.Venue_Name,Season_Year,Team_Name
),
Homeground_Bowling_Performance as (
select *,round(Total_Wickets/Matches_Played,2) as Avg_Wickets_Per_Match from Player_Performance_By_Venue
where Team_Name="Royal Challengers Bangalore" and Venue_Name="M Chinnaswamy Stadium"
),
Home_Away_Ground_Bowling_Performance as (
select *,round(Total_Wickets/Matches_Played,2) as Avg_Wickets_Per_Match from Player_Performance_By_Venue
where Team_Name="Royal Challengers Bangalore" and Venue_Name!="M Chinnaswamy Stadium"
)
select Venue_Name, sum(Total_Wickets) as Total_Wickets,sum(Matches_Played) as Matches_Played, 
	round(sum(Total_Wickets)/sum(Matches_Played),2) as Avg_Wickets_Per_Match from Homeground_Bowling_Performance
union all
select "Others" as Venue_Name, sum(Total_Wickets) as Total_Wickets,sum(Matches_Played) as Matches_Played, 
	round(sum(Total_Wickets)/sum(Matches_Played),2) as Avg_Wickets_Per_Match from Home_Away_Ground_Bowling_Performance;



-- wins and loss
with rcb_record as (
select *,(Wins+Losses) as total_matches from rcb_record
),
Homeground_Winning_Performance as (
select Venue_Name,sum(wins) as wins,sum(Losses) as losses,round((sum(wins)/sum(total_matches)*100),2) as Winning_Percentage from rcb_record
where Venue_Name = "M Chinnaswamy Stadium"
),
Other_Ground_Winning_Performance as (
select "Others" as Venue_Name,sum(wins) as wins,sum(Losses) as losses,round((sum(wins)/sum(total_matches)*100),2) as Winning_Percentage from rcb_record
where Venue_Name != "M Chinnaswamy Stadium"
)
select * from Homeground_Winning_Performance
union all
select * from Other_Ground_Winning_Performance;

  -- 9.Come up with a visual and analytical analysis with the RCB past seasons  
  -- performance and potential reasons for them not winning a trophy.

WITH RCB_Played_Matches as (
		SELECT * FROM matches as m 
		WHERE (SELECT Team_Id FROM team WHERE Team_Name = 'Royal Challengers Bangalore') IN (m.Team_1, m.Team_2)
	)
	select s.Season_Id,s.Season_Year,
		sum(case when Match_Winner=(SELECT Team_Id FROM team WHERE Team_Name = 'Royal Challengers Bangalore')
			then 1 else 0 end) as Wins,
		sum(case when Match_Winner!=(SELECT Team_Id FROM team WHERE Team_Name = 'Royal Challengers Bangalore')
			then 1 else 0 end) as Losses from RCB_Played_Matches as r
	join season as s on s.Season_Id=r.Season_Id
	group by Season_Id; 

 with Players_With_Wicket_Count_By_Season as (
	SELECT p.Player_ID, p.Player_Name,Season_Id,Venue_Id,count(Bowler) as total_wicket_count
	FROM wicket_taken AS w
	JOIN ball_by_ball AS bbb ON bbb.Ball_Id = w.Ball_Id AND bbb.Match_Id = w.Match_Id 
        AND bbb.Over_Id = w.Over_Id AND bbb.Innings_No = w.Innings_No
	join matches as m on m.Match_Id=bbb.Match_Id
	JOIN player as p ON p.Player_Id=bbb.Bowler
	GROUP BY p.Player_ID, p.Player_Name,Season_Id,Venue_Id
)
select Player_ID as Bowler_Id,Venue_Id,Player_Name as Bowler_Name,
	sum(total_wicket_count) as Total_Wicket_Count,round(avg(total_wicket_count),2) as avg_wickets,
    dense_rank() over(order by round(avg(total_wicket_count),2) desc) as Bowler_Rank 
from Players_With_Wicket_Count_By_Season
group by Venue_Id,Player_Id,Player_Name order by Bowler_Rank;


    SELECT Team_Id, s.Season_Year,
           SUM(bs.Runs_Scored + COALESCE(er.Extra_Runs, 0)) AS Total_Runs,  -- Adding extra runs
           COUNT(DISTINCT m.Match_Id) AS Matches_Played,
           ROUND(SUM(bs.Runs_Scored + COALESCE(er.Extra_Runs, 0)) / COUNT(DISTINCT m.Match_Id), 2) AS Avg_Runs_Per_Match
    FROM ball_by_ball AS bbb
    JOIN batsman_scored AS bs ON bbb.Ball_Id = bs.Ball_Id 
                              AND bbb.Match_Id = bs.Match_Id 
                              AND bbb.Over_Id = bs.Over_Id 
                              AND bbb.Innings_No = bs.Innings_No
    JOIN player AS p ON p.Player_Id = bbb.Striker
    JOIN matches AS m ON m.Match_Id = bbb.Match_Id
    JOIN season AS s ON s.Season_Id = m.Season_Id
    join player_match as pm on pm.Player_ID=p.Player_ID and pm.Match_Id=m.Match_Id
    LEFT JOIN extra_runs AS er ON bbb.Match_Id = er.Match_Id 
                               AND bbb.Ball_Id = er.Ball_Id
                               AND bbb.Over_Id = er.Over_Id
                               AND bbb.Innings_No = er.Innings_No
    GROUP BY Team_Id, s.Season_Year;  


WITH Total_Team_Runs_By_Season_Year as (
SELECT pm.Team_Id,Season_Year,
	round(coalesce(sum(bs.Runs_Scored),0)+coalesce(sum(er.Extra_Runs),0),2) as Curr_Year_Total_Runs,
    coalesce(lag(round(coalesce(sum(bs.Runs_Scored),0)+coalesce(sum(er.Extra_Runs),0),2)) over 
		(partition by pm.Team_Id order by Season_Year),0) as Prev_Year_Total_Runs
FROM ball_by_ball AS bbb
LEFT JOIN batsman_scored AS bs ON bbb.Ball_Id = bs.Ball_Id AND bbb.Match_Id = bs.Match_Id 
        AND bbb.Over_Id = bs.Over_Id AND bbb.Innings_No = bs.Innings_No
LEFT JOIN extra_runs AS er ON er.Ball_Id = bbb.Ball_Id AND er.Match_Id = bbb.Match_Id 
        AND er.Over_Id = bbb.Over_Id AND er.Innings_No = bbb.Innings_No
LEFT JOIN player as p ON p.Player_Id=bbb.Striker
join matches as m on m.Match_Id=bbb.Match_Id
join season as s on s.Season_Id=m.Season_Id
join player_match as pm on pm.Player_Id=bbb.Striker and pm.Match_Id=bbb.Match_Id
GROUP BY pm.Team_Id,Season_Year
),

Team_Wicket_Count_By_Season_Year as (
	SELECT pm.Team_Id,Season_Year,count(Bowler) as Curr_Year_Wicket_Count,
		coalesce(lag(count(Bowler)) over(partition by Team_Id order by Season_Year asc),0) as Prev_Year_Wicket_Count
	FROM wicket_taken AS w
	JOIN ball_by_ball AS bbb ON bbb.Ball_Id = w.Ball_Id AND bbb.Match_Id = w.Match_Id 
        AND bbb.Over_Id = w.Over_Id AND bbb.Innings_No = w.Innings_No
	join matches as m on m.Match_Id=bbb.Match_Id
	JOIN player as p ON p.Player_Id=bbb.Bowler
    join player_match as pm on pm.Match_Id=bbb.Match_Id and pm.Player_Id=bbb.Bowler
    join season as s on s.Season_Id=m.Season_Id
	GROUP BY pm.Team_Id,Season_Year
)
select r.Team_Id,Team_Name,r.Season_Year,Curr_Year_Total_Runs as total_runs,
	Curr_Year_Wicket_Count as Wicket_Count, 
	(case when Curr_Year_Total_Runs>Prev_Year_Total_Runs and Curr_Year_Wicket_Count>Prev_Year_Wicket_Count
		then 'Better'
        when Curr_Year_Total_Runs=Prev_Year_Total_Runs and Curr_Year_Wicket_Count=Prev_Year_Wicket_Count
        then 'Same' else 'Worse' end) as Performance
from Total_Team_Runs_By_Season_Year as r
join Team_Wicket_Count_By_Season_Year as w on w.Team_Id=r.Team_Id and w.Season_Year=r.Season_Year
join team as t on t.Team_Id=r.Team_Id 
where t.Team_Id=2;